STUDENT ID: 939206
NAME: ANDREW TJEN

Remarks:
All the function and files are inside the  jupyter notebook to recreate
the dataset and graphs shown in the report. It is according to their respective
question number. It is also possible to run the random sample test script for a
specific file with specific discretization and add-k level after the second
answered question
